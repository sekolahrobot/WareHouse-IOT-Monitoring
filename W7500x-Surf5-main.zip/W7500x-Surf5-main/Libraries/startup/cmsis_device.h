#ifndef _CMSIS_H_
#define _CMSIS_H_

#include "W7500x.h"

#endif // _CMSIS_H_
